//
//  SearchViewController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ANDREW KENEALY on 20/12/2016.
//  Copyright © 2016 SIT302-G23. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
