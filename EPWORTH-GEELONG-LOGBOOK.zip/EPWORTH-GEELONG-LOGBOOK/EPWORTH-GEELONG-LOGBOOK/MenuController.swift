//
//  MenuController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ANDREW KENEALY on 19/12/2016.
//  Copyright © 2016 SIT302-G23. All rights reserved.
//

#import "MenuController.h"

@implementation MenuController

@end
