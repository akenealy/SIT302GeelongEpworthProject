//
//  DatabaseTableViewController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ANDREW KENEALY on 20/12/2016.
//  Copyright © 2016 SIT302-G23. All rights reserved.
//

import UIKit

class DatabaseTableViewController: UITableViewController {
    
    @IBOutlet var Table: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.

        Table.dataSource = self
        Table.delegate = self
    }
    
    // Displays the number of defined rows
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    // Defines a custom cell and accompanying label
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        label.text = "Example User 1"
        cell.addSubview(label)
        return cell
    }
    
    // Defines the heigh of a Row
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 10
    }
    
    // Cell On-Click Segue functionality
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let destination = storyboard.instantiateViewControllerWithIdentifier("LogDisplayViewController") as! LogDisplayViewController
        navigationController?.pushViewController(destination, animated: true)
    }
}
