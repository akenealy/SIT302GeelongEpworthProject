//
//  ViewController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ELIAS MA on 13/12/2016.
//  Copyright © 2016 SIT102-G23. All rights reserved.
//

import UIKit


class ViewController: UIViewController {    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



}

