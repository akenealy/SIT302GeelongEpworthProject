//
//  LogCreationViewController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ANDREW KENEALY on 19/12/2016.
//  Copyright © 2016 SIT302-G23. All rights reserved.
//

import UIKit

class LogCreationViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // Procedure ListPicker
    @IBOutlet weak var picker: UIPickerView!
    
    // Gender RadioSwitches
    @IBOutlet weak var maleSwitch:UISwitch!
    @IBOutlet weak var femaleSwitch:UISwitch!
    @IBOutlet weak var otherSwitch:UISwitch!
    
    // User Input Textfields
    @IBOutlet weak var numberCase:UITextField!
    @IBOutlet weak var nameCase: UITextField!
    @IBOutlet weak var dateCase: UITextField!
    @IBOutlet weak var contactCase: UITextField!
    @IBOutlet weak var addressCase: UITextField!
    @IBOutlet weak var commentsCase: UITextView!
    
    // Variables to convert textfield input into usable strings
    var pickerData: [String] = [String]()
    var genderCase: String!
    var procedureCase: String!
    var caseData: String!
    var caseName: String!
    var caseDate: String!
    var caseGender: String!
    var caseProcedure: String!
    var caseContact: String!
    var caseAddress: String!
    var caseComments: String!
    
    // Declaration of XML tag structures
    var XMLCase: String!
    var XMLNumber: String!
    var XMLPatient: String!
    var XMLNodePatientName: String!
    var XMLNodeDate: String!
    var XMLNodeGender: String!
    var XMLProcedure: String!
    var XMLContact: String!
    var XMLNodeAddress: String!
    var XMLNodePhone: String!
    var XMLComments: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.picker.delegate = self
        self.picker.dataSource = self
        
        // Populating Procedure dropdownlist
        pickerData = ["Select One Below", "example item 1", "example item 2"]
        
    }
    
    
    @IBAction func MaleSwitchOn(sender:UISwitch){
            genderCase = "Male"
        
            // Radio functionality to ensure only chosen switch is on
            femaleSwitch.setOn(false, animated: true)
            otherSwitch.setOn(false, animated: true)
    }
    
    
    @IBAction func FemaleSwitchOn(sender:UISwitch){
            genderCase = "Female"
        
            // Radio functionality to ensure only chosen switch is on
            maleSwitch.setOn(false, animated: true)
            otherSwitch.setOn(false, animated: true)
        
    }
    
    
    @IBAction func OtherSwitchOn(sender:UISwitch){
            genderCase = "Other"
        
            // Radio functionality to ensure only chosen switch is on
            femaleSwitch.setOn(false, animated: true)
            maleSwitch.setOn(false, animated: true)
    }
    
    // Submission of completed inputs
    
    // Prototype does not include Data validation or entryfield type 
    // checking designed to guarantee successful log creation
    @IBAction func buttonSubmit(sender: UIButton) {
        
        // Conversion of Textfield inputs into localised variables
        caseData = numberCase.text
        caseName = nameCase.text
        caseDate = dateCase.text
        caseGender = genderCase
        caseProcedure = procedureCase
        caseContact = contactCase.text
        caseAddress = addressCase.text
        caseComments = commentsCase.text
        
        // Writing localised variables into XML Tags
        XMLNumber = "<Number>" + caseData + "</Number>"

        XMLNodePatientName = "<Name>" + caseName + "</Name>"
        XMLNodeDate = "<Date>" + caseDate + "</Date>"
        XMLNodeGender = "<Gender>" + caseGender + "</Gender>"
        XMLPatient = "<Patient>" + XMLNodePatientName + XMLNodeDate + XMLNodeGender + "</Patient>"
        
        XMLNodeAddress = "<Address>" + caseAddress + "</Address>"
        XMLNodePhone = "<Phone>" + caseContact + "</Phone>"
        XMLContact = "<Contact>" + XMLNodeAddress + XMLNodePhone + "</Contact>"
        
        XMLProcedure = "<Procedure>" + caseProcedure + "</Procedure>"
        
        XMLComments = "<Comments>" + caseComments + "</Comments>"
        
        XMLCase = "<Case> " + XMLNumber + " " + XMLPatient + " " + XMLContact + " " + XMLProcedure + " " + XMLComments + " " + "</Case>"
        
        // define the storage Directory path located on the iOS device
        var path = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)[0]
        // Write the data to local Directory storage in an XML File format
        do {
            path = path.stringByAppendingFormat("/" + caseData + ".xml")
            let data = NSData()
            try data.writeToFile(path, atomically: true)
        }
        // Catch any thrown erros and write to debugger
        catch let error as NSError{
            print(error.localizedDescription)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    // The data to be passed to a localised variable to be used after selection
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        procedureCase = pickerData[row]
    }
    
}
