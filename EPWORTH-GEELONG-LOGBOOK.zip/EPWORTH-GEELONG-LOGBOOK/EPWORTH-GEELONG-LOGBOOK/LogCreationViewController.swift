//
//  LogCreationViewController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ANDREW KENEALY on 19/12/2016.
//  Copyright © 2016 SIT302-G23. All rights reserved.
//

import UIKit

class LogCreationViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var picker: UIPickerView!
    
    @IBOutlet weak var maleSwitch:UISwitch!
    @IBOutlet weak var femaleSwitch:UISwitch!
    @IBOutlet weak var otherSwitch:UISwitch!
    
    @IBOutlet weak var numberCase:UITextField!
    @IBOutlet weak var nameCase: UITextField!
    @IBOutlet weak var dateCase: UITextField!
    @IBOutlet weak var contactCase: UITextField!
    @IBOutlet weak var addressCase: UITextField!
    @IBOutlet weak var commentsCase: UITextView!
    
    
    var pickerData: [String] = [String]()
    var genderCase: String!
    var procedureCase: String!
    
    var caseData: String!
    var caseName: String!
    var caseDate: String!
    var caseGender: String!
    var caseProcedure: String!
    var caseContact: String!
    var caseAddress: String!
    var caseComments: String!
    
    var XMLCase: String!
    var XMLNumber: String!
    
    var XMLPatient: String!
    var XMLNodePatientName: String!
    var XMLNodeDate: String!
    var XMLNodeGender: String!
    
    var XMLProcedure: String!
    
    var XMLContact: String!
    var XMLNodeAddress: String!
    var XMLNodePhone: String!
    
    var XMLComments: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.picker.delegate = self
        self.picker.dataSource = self
        
        pickerData = ["Select One Below", "test item 1", "test item 2"]
        
    }
    
    @IBAction func MaleSwitchOn(sender:UISwitch){
            genderCase = "Male"
            femaleSwitch.setOn(false, animated: true)
            otherSwitch.setOn(false, animated: true)
    }
    
    @IBAction func FemaleSwitchOn(sender:UISwitch){
            genderCase = "Female"
            maleSwitch.setOn(false, animated: true)
            otherSwitch.setOn(false, animated: true)
        
    }
    
    @IBAction func OtherSwitchOn(sender:UISwitch){
            genderCase = "Other"
            femaleSwitch.setOn(false, animated: true)
            maleSwitch.setOn(false, animated: true)
    }
    
    
    @IBAction func buttonSubmit(sender: UIButton) {
        
        caseData = numberCase.text
        caseName = nameCase.text
        caseDate = dateCase.text
        caseGender = genderCase
        caseProcedure = procedureCase
        caseContact = contactCase.text
        caseAddress = addressCase.text
        caseComments = commentsCase.text
        
        XMLNumber = "<Number>" + caseData + "</Number>"
        
        XMLNodePatientName = "<Name>" + caseName + "</Name>"
        XMLNodeDate = "<Date>" + caseDate + "</Date>"
        XMLNodeGender = "<Gender>" + caseGender + "</Gender>"
        XMLPatient = "<Patient>" + XMLNodePatientName + XMLNodeDate + XMLNodeGender + "</Patient>"
        
        XMLNodeAddress = "<Address>" + caseAddress + "</Address>"
        XMLNodePhone = "<Phone>" + caseContact + "</Phone>"
        XMLContact = "<Contact>" + XMLNodeAddress + XMLNodePhone + "</Contact>"
        
        XMLProcedure = "<Procedure>" + caseProcedure + "</Procedure>"
        
        XMLComments = "<Comments>" + caseComments + "</Comments>"
        
        XMLCase = "<Case>" + XMLNumber + XMLPatient + XMLContact + XMLProcedure + XMLComments + "</Case>"
        
        }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    // The data to be passed to a localised variable to be used after selection
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        procedureCase = pickerData[row]
    }
    
}
