//
//  LogCreationViewController.swift
//  EPWORTH-GEELONG-LOGBOOK
//
//  Created by ANDREW KENEALY on 19/12/2016.
//  Copyright © 2016 SIT302-G23. All rights reserved.
//

import UIKit

class LogCreationViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var picker: UIPickerView!
    
    var pickerData: [String] = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.picker.delegate = self
        self.picker.dataSource = self
        
        pickerData = ["test item 1"]
    }

    
    @IBOutlet var MaleSwitch:UISwitch!
    @IBOutlet var FemaleSwitch:UISwitch!
    @IBOutlet var OtherSwitch:UISwitch!
    
    @IBAction func MaleSwitchOn(sender:UISwitch){
        if sender.on==true{
            FemaleSwitch.setOn(false, animated: true)
            OtherSwitch.setOn(false, animated: true)
        }
        
    }
    
    @IBAction func FemaleSwitchOn(sender:UISwitch){
        if sender.on==true{
            MaleSwitch.setOn(false, animated: true)
            OtherSwitch.setOn(false, animated: true)
        }
        
    }
    
    @IBAction func OtherSwitchOn(sender:UISwitch){
        if sender.on==true{
            FemaleSwitch.setOn(false, animated: true)
            MaleSwitch.setOn(false, animated: true)
        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // The number of columns of data
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // The number of rows of data
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return pickerData.count
    }
    
    // The data to return for the row and component (column) that's being passed in
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
}
